const mysql = require("mysql2");

// change these values to match your MySQL setup
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "news_db",
});

db.connect((err) => {
  if (err) {
    console.log("Database connection failed:", err.message);
  } else {
    console.log("Connected to MySQL database");
  }
});

module.exports = db;
