const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();
app.use(cors());
app.use(express.json());

// ---------- NEWS ----------

// get all news (SELECT)
app.get("/api/news", (req, res) => {
  db.query("SELECT * FROM news ORDER BY created_at DESC", (err, result) => {
    if (err) return res.status(500).json(err);
    res.json(result);
  });
});

// get one news article (SELECT)
app.get("/api/news/:id", (req, res) => {
  db.query("SELECT * FROM news WHERE id = ?", [req.params.id], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0) return res.status(404).json({ message: "Not found" });
    res.json(result[0]);
  });
});

// add news (INSERT)
app.post("/api/news", (req, res) => {
  const { title, category, content, image_url } = req.body;
  const sql = "INSERT INTO news (title, category, content, image_url) VALUES (?, ?, ?, ?)";
  db.query(sql, [title, category, content, image_url], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json({ message: "News added", id: result.insertId });
  });
});

// edit news (UPDATE)
app.put("/api/news/:id", (req, res) => {
  const { title, category, content, image_url } = req.body;
  const sql = "UPDATE news SET title = ?, category = ?, content = ?, image_url = ? WHERE id = ?";
  db.query(sql, [title, category, content, image_url, req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: "News updated" });
  });
});

// delete news (DELETE)
app.delete("/api/news/:id", (req, res) => {
  db.query("DELETE FROM news WHERE id = ?", [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: "News deleted" });
  });
});

// ---------- CONTACT MESSAGES ----------

app.post("/api/messages", (req, res) => {
  const { name, email, message } = req.body;
  const sql = "INSERT INTO messages (name, email, message) VALUES (?, ?, ?)";
  db.query(sql, [name, email, message], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: "Message sent" });
  });
});

app.get("/api/messages", (req, res) => {
  db.query("SELECT * FROM messages ORDER BY created_at DESC", (err, result) => {
    if (err) return res.status(500).json(err);
    res.json(result);
  });
});

app.delete("/api/messages/:id", (req, res) => {
  db.query("DELETE FROM messages WHERE id = ?", [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: "Message deleted" });
  });
});

// ---------- ADMIN LOGIN ----------

app.post("/api/login", (req, res) => {
  const { username, password } = req.body;
  const sql = "SELECT * FROM admins WHERE username = ? AND password = ?";
  db.query(sql, [username, password], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length > 0) {
      res.json({ success: true });
    } else {
      res.json({ success: false, message: "Wrong username or password" });
    }
  });
});

app.listen(5001, () => {
  console.log("Server running on http://localhost:5001");
});
