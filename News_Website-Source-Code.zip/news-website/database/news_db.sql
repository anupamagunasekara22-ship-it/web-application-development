-- City News Website Database
-- Run this file in MySQL (Workbench / phpMyAdmin / command line)

CREATE DATABASE IF NOT EXISTS news_db;
USE news_db;

-- admin users table
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL
);

-- news articles table
CREATE TABLE IF NOT EXISTS news (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  category VARCHAR(50) NOT NULL,
  content TEXT NOT NULL,
  image_url VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- messages from contact us page
CREATE TABLE IF NOT EXISTS messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- sample data
INSERT INTO admins (username, password) VALUES ('admin', 'admin123');

INSERT INTO news (title, category, content, image_url) VALUES
('New Highway Opens in the City', 'Local', 'The new highway connecting the city centre to the airport was opened today. It is expected to reduce travel time by 30 minutes.', 'https://picsum.photos/id/1011/600/350'),
('National Cricket Team Wins Series', 'Sports', 'The national cricket team won the three match series 2-1 after a thrilling final match on Sunday.', 'https://picsum.photos/id/1058/600/350'),
('Tech Expo 2026 Starts Next Week', 'Technology', 'The annual tech expo will start next week with more than 100 companies showing their latest products.', 'https://picsum.photos/id/0/600/350'),
('Heavy Rain Expected This Weekend', 'Weather', 'The weather department has warned that heavy rain is expected in most areas this weekend.', 'https://picsum.photos/id/1015/600/350');

-- Example DML queries used in the website:
-- SELECT * FROM news ORDER BY created_at DESC;
-- INSERT INTO news (title, category, content, image_url) VALUES (?, ?, ?, ?);
-- UPDATE news SET title=?, category=?, content=?, image_url=? WHERE id=?;
-- DELETE FROM news WHERE id=?;
