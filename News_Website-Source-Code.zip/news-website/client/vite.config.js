import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    // send /api requests to the express server
    proxy: {
      "/api": "http://localhost:5001",
    },
  },
});
