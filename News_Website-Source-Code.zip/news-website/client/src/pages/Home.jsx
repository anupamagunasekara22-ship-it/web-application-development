import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import NewsCard from "../components/NewsCard";

function Home() {
  const [news, setNews] = useState([]);

  useEffect(() => {
    fetch("/api/news")
      .then((res) => res.json())
      .then((data) => setNews(data.slice(0, 3)))
      .catch((err) => console.log(err));
  }, []);

  return (
    <div>
      <div className="hero">
        <h1>Welcome to City News</h1>
        <p>Latest local, sports, technology and weather news in one place.</p>
        <Link to="/news" className="btn">View All News</Link>
      </div>

      <h2>Latest News</h2>
      <div className="grid">
        {news.map((item) => (
          <NewsCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
}

export default Home;
