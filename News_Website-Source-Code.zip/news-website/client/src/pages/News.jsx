import { useEffect, useState } from "react";
import NewsCard from "../components/NewsCard";

function News() {
  const [news, setNews] = useState([]);
  const [category, setCategory] = useState("All");

  useEffect(() => {
    fetch("/api/news")
      .then((res) => res.json())
      .then((data) => setNews(data))
      .catch((err) => console.log(err));
  }, []);

  const categories = ["All", "Local", "Sports", "Technology", "Weather"];

  const filtered = category === "All" ? news : news.filter((n) => n.category === category);

  return (
    <div>
      <h1>All News</h1>

      <div className="filter">
        {categories.map((c) => (
          <button
            key={c}
            className={category === c ? "active" : ""}
            onClick={() => setCategory(c)}
          >
            {c}
          </button>
        ))}
      </div>

      {filtered.length === 0 && <p>No news found.</p>}

      <div className="grid">
        {filtered.map((item) => (
          <NewsCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
}

export default News;
