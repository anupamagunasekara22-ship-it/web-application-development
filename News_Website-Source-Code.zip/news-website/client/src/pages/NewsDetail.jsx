import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";

function NewsDetail() {
  const { id } = useParams();
  const [item, setItem] = useState(null);

  useEffect(() => {
    fetch("/api/news/" + id)
      .then((res) => res.json())
      .then((data) => setItem(data))
      .catch((err) => console.log(err));
  }, [id]);

  if (!item) return <p>Loading...</p>;
  if (!item.id) return <p>News not found.</p>;

  return (
    <div className="detail">
      <Link to="/news">&larr; Back to News</Link>
      <h1>{item.title}</h1>
      <p className="meta">
        {item.category} | {new Date(item.created_at).toLocaleDateString()}
      </p>
      {item.image_url && <img src={item.image_url} alt={item.title} />}
      <p>{item.content}</p>
    </div>
  );
}

export default NewsDetail;
