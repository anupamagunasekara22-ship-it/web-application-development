import { useState } from "react";

function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch("/api/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    })
      .then((res) => res.json())
      .then(() => {
        setStatus("Thank you! Your message has been sent.");
        setForm({ name: "", email: "", message: "" });
      })
      .catch(() => setStatus("Something went wrong. Try again."));
  };

  return (
    <div className="contact">
      <h1>Contact Us</h1>
      <p>Email: info@citynews.lk | Phone: 011 234 5678</p>

      <form onSubmit={handleSubmit} className="form">
        <input name="name" placeholder="Your Name" value={form.name} onChange={handleChange} required />
        <input name="email" type="email" placeholder="Your Email" value={form.email} onChange={handleChange} required />
        <textarea name="message" placeholder="Your Message" rows="5" value={form.message} onChange={handleChange} required />
        <button type="submit" className="btn">Send</button>
      </form>

      {status && <p className="status">{status}</p>}
    </div>
  );
}

export default Contact;
