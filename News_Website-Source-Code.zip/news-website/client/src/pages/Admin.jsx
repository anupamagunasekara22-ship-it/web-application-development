import { useEffect, useState } from "react";

const emptyForm = { title: "", category: "Local", content: "", image_url: "" };

function Admin() {
  const [loggedIn, setLoggedIn] = useState(localStorage.getItem("admin") === "yes");
  const [login, setLogin] = useState({ username: "", password: "" });
  const [error, setError] = useState("");

  const [news, setNews] = useState([]);
  const [messages, setMessages] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editId, setEditId] = useState(null);

  const loadData = () => {
    fetch("/api/news").then((res) => res.json()).then((data) => setNews(data));
    fetch("/api/messages").then((res) => res.json()).then((data) => setMessages(data));
  };

  useEffect(() => {
    if (loggedIn) loadData();
  }, [loggedIn]);

  // ----- login -----
  const handleLogin = (e) => {
    e.preventDefault();
    fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(login),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          localStorage.setItem("admin", "yes");
          setLoggedIn(true);
        } else {
          setError(data.message);
        }
      });
  };

  const handleLogout = () => {
    localStorage.removeItem("admin");
    setLoggedIn(false);
  };

  // ----- add / update news -----
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const url = editId ? "/api/news/" + editId : "/api/news";
    const method = editId ? "PUT" : "POST";

    fetch(url, {
      method: method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    }).then(() => {
      alert(editId ? "News updated!" : "News added!");
      setForm(emptyForm);
      setEditId(null);
      loadData();
    });
  };

  const handleEdit = (item) => {
    setEditId(item.id);
    setForm({
      title: item.title,
      category: item.category,
      content: item.content,
      image_url: item.image_url || "",
    });
    window.scrollTo(0, 0);
  };

  // ----- delete -----
  const deleteNews = (id) => {
    if (!window.confirm("Delete this news?")) return;
    fetch("/api/news/" + id, { method: "DELETE" }).then(() => loadData());
  };

  const deleteMessage = (id) => {
    if (!window.confirm("Delete this message?")) return;
    fetch("/api/messages/" + id, { method: "DELETE" }).then(() => loadData());
  };

  // ----- login page -----
  if (!loggedIn) {
    return (
      <div className="login">
        <h1>Admin Login</h1>
        <form onSubmit={handleLogin} className="form">
          <input placeholder="Username" value={login.username}
            onChange={(e) => setLogin({ ...login, username: e.target.value })} required />
          <input type="password" placeholder="Password" value={login.password}
            onChange={(e) => setLogin({ ...login, password: e.target.value })} required />
          <button type="submit" className="btn">Login</button>
        </form>
        {error && <p className="error">{error}</p>}
      </div>
    );
  }

  // ----- admin dashboard -----
  return (
    <div>
      <div className="admin-header">
        <h1>Admin Dashboard</h1>
        <button onClick={handleLogout} className="btn btn-red">Logout</button>
      </div>

      <h2>{editId ? "Edit News" : "Add News"}</h2>
      <form onSubmit={handleSubmit} className="form">
        <input name="title" placeholder="Title" value={form.title} onChange={handleChange} required />
        <select name="category" value={form.category} onChange={handleChange}>
          <option>Local</option>
          <option>Sports</option>
          <option>Technology</option>
          <option>Weather</option>
        </select>
        <input name="image_url" placeholder="Image URL (optional)" value={form.image_url} onChange={handleChange} />
        <textarea name="content" placeholder="Content" rows="5" value={form.content} onChange={handleChange} required />
        <div>
          <button type="submit" className="btn">{editId ? "Update" : "Add"}</button>
          {editId && (
            <button type="button" className="btn btn-grey"
              onClick={() => { setEditId(null); setForm(emptyForm); }}>
              Cancel
            </button>
          )}
        </div>
      </form>

      <h2>All News</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Category</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {news.map((item) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>{item.title}</td>
              <td>{item.category}</td>
              <td>
                <button className="btn" onClick={() => handleEdit(item)}>Edit</button>
                <button className="btn btn-red" onClick={() => deleteNews(item.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Contact Messages</h2>
      {messages.length === 0 && <p>No messages yet.</p>}
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {messages.map((m) => (
            <tr key={m.id}>
              <td>{m.name}</td>
              <td>{m.email}</td>
              <td>{m.message}</td>
              <td>
                <button className="btn btn-red" onClick={() => deleteMessage(m.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Admin;
