function About() {
  return (
    <div className="about">
      <h1>About Us</h1>
      <p>
        City News is a small online news website that gives readers the latest
        news about local events, sports, technology and weather.
      </p>
      <h3>Our Mission</h3>
      <p>To provide fast, simple and correct news to everyone.</p>
      <h3>Our Team</h3>
      <ul>
        <li>Editor - Writes and checks news articles</li>
        <li>Reporter - Collects news from around the city</li>
        <li>Admin - Manages the website</li>
      </ul>
    </div>
  );
}

export default About;
