function Footer() {
  return (
    <footer className="footer">
      <p>&copy; 2026 City News. All rights reserved.</p>
    </footer>
  );
}

export default Footer;
