import { Link } from "react-router-dom";

function NewsCard({ item }) {
  return (
    <div className="card">
      {item.image_url && <img src={item.image_url} alt={item.title} />}
      <div className="card-body">
        <span className="category">{item.category}</span>
        <h3>{item.title}</h3>
        <p>{item.content.substring(0, 100)}...</p>
        <Link to={"/news/" + item.id} className="btn">Read More</Link>
      </div>
    </div>
  );
}

export default NewsCard;
