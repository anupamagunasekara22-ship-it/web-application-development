# City News - Web Application Development Assignment

A simple news website made with **React, HTML, CSS, JavaScript, Node.js (Express) and MySQL**.

## Pages
1. Home - welcome banner and latest 3 news
2. News - all news with category filter (plus a page for reading one article)
3. About Us - information about the website
4. Contact Us - contact form (saved to database)
5. Admin - login, add / edit / delete news, view / delete contact messages

## DML Operations
| Operation | Where it is used |
|-----------|------------------|
| SELECT | Showing news, admin login, viewing messages |
| INSERT | Admin adds news, user sends contact message |
| UPDATE | Admin edits news |
| DELETE | Admin deletes news or messages |

## Folder Structure
```
news-website/
├── database/news_db.sql   -> database tables + sample data
├── server/                -> Express backend (API)
│   ├── db.js
│   └── server.js
└── client/                -> React frontend
    └── src/
        ├── components/    -> Navbar, Footer, NewsCard
        └── pages/         -> Home, News, NewsDetail, About, Contact, Admin
```

## How to Run

### Requirements
- Node.js
- MySQL (XAMPP / WAMP / MySQL Workbench)

### 1. Database
Open MySQL and run the file `database/news_db.sql`.
(In phpMyAdmin: Import -> choose the file -> Go)

### 2. Backend
Open `server/db.js` and change the MySQL username and password if needed.
```
cd server
npm install
npm start
```
Server runs on http://localhost:5001

### 3. Frontend
Open a new terminal:
```
cd client
npm install
npm run dev
```
Open http://localhost:3000 in the browser.

### Admin Login
- Username: `admin`
- Password: `admin123`
